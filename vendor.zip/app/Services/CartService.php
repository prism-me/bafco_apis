<?php

namespace App\Services;

class CartService {

    public function addToCart($data){
        return 'product has been addded to cart';
    }
}