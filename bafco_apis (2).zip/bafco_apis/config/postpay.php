<?php

use Illuminate\Support\Str;

return [
    
    'base_code' => env('POSTPAY_BASECODE', 'aWRfNDBhYzA1MDY1ZDU3NGE3MmI4NDg1YTZkNTIxNjI2Yjg6c2tfdGVzdF9kZDI4YzQyOGVkNDM5NzMxOGViNjVjMjAwOWIwM2Q5MTU4MDM2Yjky'),

    'base_url' => env('POSTPAY_BASE_URL', 'https://sandbox.postpay.io'),
    

];